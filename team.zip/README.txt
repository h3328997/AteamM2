ATEAM 81 Quiz Generator
Authors: Yifei Fan, Lec 004, Xteam 126; Sammy Gomez, Lec 004, Xteam 89; Hunter Ward, Lec 004, Xteam 89

I use intellij as my IDE so files may look different than Eclipse.  Look in /src/ folder for files to copy into 
your eclipse project.  Should only need to add main.java and styles.css.